#!/usr/bin/env bash
# sync.sh — importa gli standards dell'ecosistema EAR Lab Famiglia
# nella repo corrente.
#
# Uso:
#   curl -fsSL https://raw.githubusercontent.com/raydalessandro/ear-lab-standards/main/scripts/sync.sh | bash
#
# Oppure (consigliato, una volta che hai lo script committato nella tua repo):
#   ./scripts/sync-standards.sh
#
# Cosa fa:
# 1. Clona ear-lab-standards in /tmp con --depth 1.
# 2. Confronta la versione remota con quella locale (.ear-lab-standards-version).
# 3. Se diversa, mostra il diff del CHANGELOG e chiede conferma.
# 4. Copia test/ e .github/ dalla sorgente al repo corrente.
# 5. Aggiorna .ear-lab-standards-version con la nuova versione.
#
# Cosa NON fa:
# - Non tocca i file della repo che non sono in test/ o .github/.
# - Non sovrascrive .github/workflows/*.yml diversi da ci.yml (puoi avere
#   workflow custom oltre a quello standard).
# - Non fa commit. Sei tu a decidere quando e come committare.

set -euo pipefail

# ============================================================
# Configurazione
# ============================================================

STANDARDS_REPO="https://github.com/raydalessandro/ear-lab-standards.git"
STANDARDS_BRANCH="main"
VERSION_FILE=".ear-lab-standards-version"
TEMP_DIR="$(mktemp -d)"

# Pulizia al exit
trap 'rm -rf "$TEMP_DIR"' EXIT

# Colori (se il terminale li supporta)
if [ -t 1 ]; then
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[0;33m'
  BLUE='\033[0;34m'
  RESET='\033[0m'
else
  RED='' GREEN='' YELLOW='' BLUE='' RESET=''
fi

info()  { printf "${BLUE}[info]${RESET} %s\n" "$*"; }
ok()    { printf "${GREEN}[ok]${RESET} %s\n" "$*"; }
warn()  { printf "${YELLOW}[warn]${RESET} %s\n" "$*"; }
error() { printf "${RED}[error]${RESET} %s\n" "$*"; exit 1; }

# ============================================================
# Verifica preconditions
# ============================================================

[ -f "package.json" ] || error "Non sembra una repo JS/TS valida (manca package.json). Lancia lo script dalla root del repo."

command -v git >/dev/null 2>&1 || error "git non installato."

# ============================================================
# Clone della sorgente
# ============================================================

info "Clono ear-lab-standards in $TEMP_DIR..."
git clone --depth 1 --branch "$STANDARDS_BRANCH" "$STANDARDS_REPO" "$TEMP_DIR" >/dev/null 2>&1 \
  || error "Impossibile clonare $STANDARDS_REPO. Verifica connessione e accesso."

# Estrae la versione corrente dal CHANGELOG (prima riga `## [x.y.z]`)
REMOTE_VERSION=$(grep -m1 -oE '^## \[[0-9]+\.[0-9]+\.[0-9]+\]' "$TEMP_DIR/CHANGELOG.md" \
  | sed -E 's/## \[([0-9.]+)\]/\1/' || echo "unknown")

info "Versione remota disponibile: $REMOTE_VERSION"

# ============================================================
# Versione locale e diff changelog
# ============================================================

LOCAL_VERSION=""
if [ -f "$VERSION_FILE" ]; then
  LOCAL_VERSION=$(cat "$VERSION_FILE" | tr -d '[:space:]')
  info "Versione locale: $LOCAL_VERSION"
else
  warn "Nessuna versione locale registrata — è la prima sync su questa repo."
fi

if [ "$LOCAL_VERSION" = "$REMOTE_VERSION" ]; then
  ok "Sei già allineato alla versione $REMOTE_VERSION. Niente da fare."
  exit 0
fi

# Mostra le voci del changelog tra locale e remoto
if [ -n "$LOCAL_VERSION" ]; then
  echo ""
  info "Modifiche tra $LOCAL_VERSION e $REMOTE_VERSION:"
  echo ""
  # Estrae la sezione del changelog dalla versione remota a quella locale (esclusa)
  awk -v from="$REMOTE_VERSION" -v to="$LOCAL_VERSION" '
    /^## \[/ {
      match($0, /\[[0-9.]+\]/)
      ver = substr($0, RSTART+1, RLENGTH-2)
      if (ver == to) { exit }
      printing = 1
    }
    printing { print }
  ' "$TEMP_DIR/CHANGELOG.md"
  echo ""
fi

# ============================================================
# Conferma
# ============================================================

read -rp "Applico la sync? [y/N] " confirm
case "$confirm" in
  [yY]|[yY][eE][sS]) ;;
  *) info "Annullato dall'utente."; exit 0 ;;
esac

# ============================================================
# Applicazione: copia test/ e .github/
# ============================================================

info "Copio test/..."
mkdir -p test
# rsync mantiene i file della repo che non sono nel template (utile se hai
# pattern locali aggiuntivi, anche se sconsigliato).
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete "$TEMP_DIR/test/" "./test/"
else
  rm -rf test
  cp -R "$TEMP_DIR/test" "./test"
fi
ok "test/ aggiornata."

info "Copio workflow CI..."
mkdir -p .github/workflows .github/actions/install
cp "$TEMP_DIR/test/ci-cd/workflow-template.yml" ".github/workflows/ci.yml"
cp "$TEMP_DIR/test/ci-cd/install-action.yml" ".github/actions/install/action.yml"
ok ".github/workflows/ci.yml e .github/actions/install/action.yml aggiornati."

# Aggiorna il file di versione
echo "$REMOTE_VERSION" > "$VERSION_FILE"
ok "Versione registrata: $REMOTE_VERSION"

# ============================================================
# Promemoria post-sync
# ============================================================

echo ""
ok "Sync completata."
echo ""
echo "Prossimi passi:"
echo "  1. git diff   → controlla cosa è cambiato."
echo "  2. Se è la prima sync, vai su GitHub → Settings → Branches e crea"
echo "     la branch protection rule per main (dettagli in"
echo "     test/ci-cd/branch-protection.md)."
echo "  3. Commit + push."
