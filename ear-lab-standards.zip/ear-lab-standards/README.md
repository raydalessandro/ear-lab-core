# ear-lab-standards

> Knowledge base operativa dell'ecosistema EAR Lab Famiglia.
> Pattern, anti-pattern, template CI/CD, e workflow condivisi tra tutti i repo.

---

## Cos'è e cosa non è

**È** una sorgente di verità per:
- Pattern di test (TDD, E2E) replicabili tra progetti.
- Anti-pattern noti, con la forma universale dell'errore.
- Template CI/CD (GitHub Actions + Vercel + branch protection).
- Convenzioni operative comuni.

**Non è**:
- Una libreria di codice riusabile. Per quella c'è il progetto separato
  `ear-lab-modules` (o nome equivalente).
- Una documentazione esaustiva. Sono *decisioni chiuse* e *pattern ricorrenti*,
  non un manuale completo.
- Un blog. Ogni file è prescrittivo: dice cosa fare, non racconta perché in
  generale è interessante.

---

## Struttura

```
ear-lab-standards/
  README.md              ← questo file
  CHANGELOG.md           ← changelog globale della repo
  scripts/
    sync.sh              ← script che ogni repo consuma per importare gli standards
  test/
    README.md            ← indice della knowledge base test
    ci-cd/
      SKILL.md           ← pattern fisso CI/CD
      workflow-template.yml
      install-action.yml
      branch-protection.md
      applicazione-repo.md
    tdd/
      SKILL.md           ← (da popolare)
      patterns/
      anti-patterns/
    e2e/
      SKILL.md           ← (da popolare)
      patterns/
      anti-patterns/
```

---

## Come la usi nei tuoi repo

In ogni repo dell'ecosistema, una volta sola:

1. Aggiungi `scripts/sync-standards.sh` al repo (copialo da `scripts/sync.sh`
   di questa repo, oppure scrivi un alias minimo che fa la stessa cosa).
2. Lancialo: clona questa repo in temp, copia la cartella `test/` e il
   workflow CI nella tua repo, registra la versione importata in
   `.ear-lab-standards-version`.
3. Committa il risultato.

Da quel momento in poi:
- Quando aggiorni `ear-lab-standards` (es. nuovi pattern, fix al workflow),
  rilanci `./scripts/sync-standards.sh` nei repo che vuoi aggiornare.
- Il file `.ear-lab-standards-version` ti dice da che versione viene il
  contenuto attuale. Se la sorgente è più nuova, lo script te lo dice.

Dettagli completi nei commenti di `scripts/sync.sh`.

### Perché non submodule, non subtree, non monorepo

**Submodule**: fragili, l'AI sbaglia spesso a gestirli, clone con `--recursive`
dimenticato porta a stati incoerenti.
**Subtree**: meno fragili dei submodule ma richiedono comandi git specifici
da imparare e mantenere.
**Monorepo**: cambierebbe l'architettura di tutto l'ecosistema (deploy
Vercel, branch protection, struttura git). Sproporzionato finché si
condividono solo convenzioni e non *codice*.

La copia + sync script è la soluzione meno potente sulla carta, ma è
quella che meno si rompe nella pratica. È una scelta deliberata.

---

## Filosofia

Tre principi, da rileggere ogni volta che si aggiunge qualcosa.

### 1. Pattern, non istanze

Quando incontri un errore, prima di sistemarlo chiediti: qual è la **forma
universale** di questo errore? Quella forma diventa un anti-pattern in
`*/anti-patterns/`. La prossima volta che stai per produrre lo stesso
errore (o un'AI per te), il file lo blocca.

### 2. Scheletro fisso, carne evolutiva

`ci-cd/` è scheletro: una volta scritto, non si tocca quasi mai (cambia
solo se cambia GitHub Actions o Vercel). `tdd/patterns/`, `tdd/anti-patterns/`,
`e2e/patterns/`, `e2e/anti-patterns/` sono carne: crescono ogni settimana
con quello che impari sul campo.

### 3. Prescrittivo, non descrittivo

Ogni file deve poter essere **eseguito** da un'AI o da un nuovo
collaboratore senza interpretazione. Non "preferisci test ai mock", ma
"se hai più di 3 mock in un test, fermati e rifattorizza la funzione".

---

## Formato standard dei file

### File `SKILL.md`

Intestazione fissa:

```markdown
# [Nome dell'area]

> Versione: YYYY-MM-DD
> Status: Provvisorio | Consolidato | Da rivedere
> Trigger di revisione:
>   - [evento concreto che dovrebbe far riaprire questo file]

[corpo del documento]

## Changelog
- YYYY-MM-DD: prima versione
- YYYY-MM-DD: [cosa è cambiato e perché]
```

I trigger sono **eventi del mondo reale**, non scadenze calendariali. Una
data sul calendario scade in solitudine. Un evento ("se la CI passa i 10
minuti", "se aggiungiamo un repo non-Next.js") lo noterai per forza durante
il lavoro.

### File `patterns/*.md` e `anti-patterns/*.md`

```markdown
# [Nome del pattern o anti-pattern]

## Quando si manifesta
[Situazione concreta in cui ricorre]

## Forma (lo schema astratto)
[Cosa è universale, applicabile ovunque]

## Esempio nel nostro ecosistema
[Path relativi a uno o più repo. Esempio:
- Soldi_Lab: `src/lib/insights/floor.ts` + `floor.test.ts`
- la-famiglia: `src/lib/auth.ts`]

## Perché funziona / perché è un errore
[La ragione strutturale, non l'opinione]

## Correlati
[Link ad altri file di questa knowledge base]

## Stato
Provvisorio | Consolidato | Da rivedere

## Ultimo check
Path verificati il YYYY-MM-DD
```

Gli **esempi reali** invecchiano (un file viene rinominato, un modulo
sparisce). Per questo c'è il campo "Ultimo check": quando rivedi il
pattern, riverifichi che i path siano ancora validi. Se trovi un link
morto, è il segnale che il pattern andava rivisto comunque.

---

## Versioning della repo

Ogni cambiamento significativo:
1. Aggiorna il `Changelog` del file modificato.
2. Aggiorna il `CHANGELOG.md` di radice con la sintesi.
3. Tagga il commit con un version bump (`v1.0`, `v1.1`, `v2.0` semver-style).

Convenzione versioni:
- **major**: cambia il *pattern fisso* (es. abbandoniamo Vercel, cambiamo
  package manager standard). I repo a valle devono prendere atto.
- **minor**: nuovi pattern o anti-pattern aggiunti, miglioramenti
  retrocompatibili al workflow.
- **patch**: typo, link rotti, esempi aggiornati.

I repo a valle, nel `.ear-lab-standards-version`, registrano l'ultima
versione importata. Quando viene rilanciato `sync.sh`, lo script confronta
con la versione corrente di questa repo e mostra il diff del changelog
tra le due versioni.

---

## Stato attuale

| Area     | Stato                  | Note                                    |
|----------|------------------------|-----------------------------------------|
| `ci-cd/` | ✅ Consolidato         | Workflow universale, pronto da applicare|
| `tdd/`   | ⏳ Scheletro           | Da popolare con pattern e anti-pattern  |
| `e2e/`   | ⏳ Scheletro           | Da popolare con pattern e anti-pattern  |
