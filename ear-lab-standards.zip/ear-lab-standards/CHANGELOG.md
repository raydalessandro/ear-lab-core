# Changelog — ear-lab-standards

Tutte le modifiche significative agli standards condivisi.

Formato: [versione] — YYYY-MM-DD
Categorie: Added, Changed, Removed, Fixed.

---

## [Unreleased]

### Added
- (in arrivo) Primi pattern in `test/tdd/`
- (in arrivo) Primi pattern in `test/e2e/`

---

## [1.0.0] — 2026-05-14

### Added
- Struttura iniziale della repo.
- `test/README.md`: indice, filosofia, formato standard dei pattern.
- `test/ci-cd/SKILL.md`: pattern fisso CI/CD (push branch → CI, PR →
  CI integrata, branch protection blocca merge).
- `test/ci-cd/workflow-template.yml`: GitHub Actions universale,
  adattivo per pnpm/npm e per script disponibili.
- `test/ci-cd/install-action.yml`: composite action per install
  dipendenze.
- `test/ci-cd/branch-protection.md`: setup operativo della rule su
  GitHub.
- `test/ci-cd/applicazione-repo.md`: note specifiche per la-famiglia,
  Spotimai, Ricette_Lab, Soldi_Lab.
- `scripts/sync.sh`: script di import degli standards nei repo a valle.

### Note
Prima versione completa per applicazione ai 4 repo dell'ecosistema attuali.
