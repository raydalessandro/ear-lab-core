# Changelog — ear-lab-standards

Tutte le modifiche significative agli standards condivisi.

Formato: [versione] — YYYY-MM-DD
Categorie: Added, Changed, Removed, Fixed.

---

## [Unreleased]

### Added
- (in arrivo) Primi pattern in `test/tdd/`
- (in arrivo) Primi pattern in `test/e2e/`

### Fixed
- `test/ci-cd/workflow-template.yml`: il sentinel `CI Success` non può
  più diventare verde a vuoto. Se `setup` falliva, tutti i job a valle
  risultavano `skipped`, il loop non trovava nessun `failure` e il check
  usato dalla branch protection passava senza aver eseguito un solo test.
  Ora il sentinel verifica l'esito di `setup` e confronta ogni job con il
  proprio output `has-*`: saltato perché lo script non esiste è
  legittimo, saltato pur essendo dichiarato è rosso.
- `test/ci-cd/workflow-template.yml`: detection di `has-e2e`. La helper
  `has()` esce sempre con `0` (stampa "true"/"false"), quindi
  `has test:e2e || has e2e` non valutava mai il secondo ramo: un repo con
  lo script `e2e` ma senza `test:e2e` non faceva girare gli E2E.

### Changed
- `test/ci-cd/workflow-template.yml`: `push` limitato a `[main]`. Un push
  su un branch con PR aperta scatenava due run identiche (`push` +
  `pull_request`) che non si cancellavano a vicenda perché il concurrency
  group è diverso. Conseguenza da conoscere: un push su un branch **senza**
  PR aperta ora non fa girare più niente.

---

## [1.0.0] — 2026-05-14

### Added
- Struttura iniziale della repo.
- `test/README.md`: indice, filosofia, formato standard dei pattern.
- `test/ci-cd/SKILL.md`: pattern fisso CI/CD (push branch → CI, PR →
  CI integrata, branch protection blocca merge).
- `test/ci-cd/workflow-template.yml`: GitHub Actions universale,
  adattivo per pnpm/npm e per script disponibili.
- `test/ci-cd/install-action.yml`: composite action per install
  dipendenze.
- `test/ci-cd/branch-protection.md`: setup operativo della rule su
  GitHub.
- `test/ci-cd/applicazione-repo.md`: note specifiche per la-famiglia,
  Spotimai, Ricette_Lab, Soldi_Lab.
- `scripts/sync.sh`: script di import degli standards nei repo a valle.

### Note
Prima versione completa per applicazione ai 4 repo dell'ecosistema attuali.
