# E2E — pattern di test end-to-end

> Versione: 2026-05-14
> Status: Provvisorio (scheletro, da popolare con i primi pattern)
> Trigger di revisione:
>   - Quando aggiungiamo il primo pattern reale → rivedere assunzioni
>   - Quando un test E2E diventa flaky → catalogare la causa come
>     anti-pattern, non sopprimere il sintomo
>   - Quando i tempi E2E in CI superano i 5 minuti → rivedere selezione e
>     parallelizzazione

---

## Decisioni chiuse (per ora)

### Stack

- **Test runner**: Playwright. Non Cypress, non Selenium.
- **Browser di default**: solo Chromium in CI. Firefox/WebKit solo per
  feature browser-specific noti (es. service worker su Safari).
- **Posizione**: cartella `e2e/` alla radice del repo, **non** dentro
  `src/`. È una cosa separata dall'app.
- **Naming**: `*.spec.ts`, non `*.test.ts`. Distinguono visivamente dai
  test Vitest.

### Pattern fondamentale: webServer integrato

Il `playwright.config.ts` deve avviare il server in autonomia:

```ts
webServer: {
  command: 'npm run build && npm start',  // produzione-like
  port: 3000,
  reuseExistingServer: !process.env.CI,
}
```

**Perché build+start invece di `npm run dev`**: il dev server ha HMR e
overlay di errore che possono interferire con i test. Si testa la versione
che andrà davvero in produzione.

In locale, `reuseExistingServer: true` permette di tenere `npm run dev`
aperto in un terminale e lanciare gli E2E in un altro senza riavvii.

### Cosa testare in E2E

- **Flussi critici end-to-end**: login → azione principale → logout.
- **Integrazioni che attraversano più moduli**: es. crea elemento →
  verifica che compaia nella lista → modificalo → verifica che il totale
  aggregato sia aggiornato.
- **Roundtrip di dati**: export → reimport → verifica integrità (vedi
  Soldi_Lab `backup.spec.ts`).

### Cosa NON testare in E2E

- **Logica già coperta da unit/integration**: gli E2E sono lenti e flaky
  rispetto agli unit. Se il calcolo funziona, lo testa un unit. L'E2E
  verifica che l'utente lo *veda* correttamente, non che il numero sia
  giusto.
- **Edge case di validazione form**: un unit sul validatore Zod copre il
  100% dei casi in millisecondi. L'E2E ne copre uno o due, per
  smoke-testing.
- **Casi di errore di rete**: testarli in E2E è doloroso e fragile.
  Mockali nei test unit.

### Selettori: data-testid sempre

```tsx
<button data-testid="floor-add">Aggiungi voce</button>
```

```ts
await page.getByTestId('floor-add').click();
```

Mai selettori basati su:
- **CSS classes** (cambiano con refactor di styling)
- **Testi visibili** (`getByText`), tranne casi dove il testo *è* il
  contratto (es. titolo della pagina)
- **Strutture DOM** (`page.locator('div > span:nth-child(3)')` — mai)

I `data-testid` sono un contratto esplicito tra UI e test. Rinominarli
richiede aggiornamento esplicito da entrambe le parti, e questo è bene.

### Stato pulito tra test

```ts
test.beforeEach(async ({ page }) => {
  await page.goto('/');
  // reset IndexedDB / localStorage / cookie
  await page.evaluate(() => {
    indexedDB.deleteDatabase('soldi_lab');
    localStorage.clear();
  });
});
```

Nessun test deve dipendere dall'ordine di esecuzione né dallo stato lasciato
da test precedenti.

---

## Pattern (da popolare)

`patterns/` raccoglierà:
- `01-data-testid-discipline.md`
- `02-webserver-integrato.md`
- `03-roundtrip-flow-testing.md`
- `04-multi-device-scenarios.md`  ← suggerito nel review di Soldi_Lab
- ...

## Anti-pattern (da popolare)

`anti-patterns/` raccoglierà:
- `01-flaky-timing-waitfor-vs-sleep.md`  ← `page.waitForTimeout` è quasi
  sempre l'errore
- `02-selettori-css-fragili.md`
- `03-test-dipendenti-da-ordine.md`
- `04-mock-via-network-interception.md` — quando va bene, quando no
- ...

---

## Changelog

- 2026-05-14: scheletro iniziale con decisioni chiuse derivate dall'analisi
  di Soldi_Lab e la-famiglia. Pattern concreti da popolare nelle prossime
  revisioni.
