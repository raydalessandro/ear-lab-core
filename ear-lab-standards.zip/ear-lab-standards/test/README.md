# test/

Knowledge base operativa per i test. Tre aree:

```
test/
  ci-cd/       Pattern fisso CI/CD (GitHub Actions + Vercel + branch protection)
  tdd/         Pattern e anti-pattern per test unit e integration
  e2e/         Pattern e anti-pattern per test end-to-end
```

Ogni area ha un `SKILL.md` con le decisioni chiuse e i template operativi.
Le sotto-cartelle `patterns/` e `anti-patterns/` raccolgono i casi
specifici, un file per pattern, secondo il formato standard.

---

## Come la usano i repo a valle

Questa cartella vive nella repo `ear-lab-standards` ed è importata nei
repo a valle tramite `scripts/sync.sh`. In ogni repo dell'ecosistema, nel
`CLAUDE.md` (o equivalente), c'è una sezione:

```markdown
## Test discipline
Prima di scrivere o modificare CI, test unit o E2E in questo repo, leggi:
- `test/ci-cd/SKILL.md` — pattern fisso CI/CD
- `test/tdd/SKILL.md` — come testiamo le funzioni pure e i repository
- `test/e2e/SKILL.md` — come testiamo i flussi end-to-end

Le decisioni in quei file sono chiuse — modifiche solo via PR su
ear-lab-standards, mai locali al singolo repo.
```

Le modifiche locali ai file in `test/` di un repo a valle verranno
**sovrascritte** dal prossimo sync. Per cambiare un pattern, si modifica
qui in `ear-lab-standards`, si bumpa la versione, e si sincronizza nei
repo a valle.

---

## Filosofia (riassunto, dettagli nel README di radice)

1. **Pattern, non istanze** — cattura la forma universale dell'errore.
2. **Scheletro fisso, carne evolutiva** — CI/CD non si tocca, TDD/E2E
   crescono.
3. **Prescrittivo, non descrittivo** — eseguibile da un'AI senza
   interpretazione.

---

## Formato standard

### SKILL.md (per area)

```markdown
# [Nome dell'area]

> Versione: YYYY-MM-DD
> Status: Provvisorio | Consolidato | Da rivedere
> Trigger di revisione:
>   - [evento concreto]

[corpo]

## Changelog
- YYYY-MM-DD: [cosa è cambiato]
```

### patterns/*.md e anti-patterns/*.md

```markdown
# [Nome]

## Quando si manifesta
[Situazione concreta]

## Forma (lo schema astratto)
[Cosa è universale]

## Esempio nel nostro ecosistema
- [Repo]: `path/relativo/al/file.ts` (+ test correlato)

## Perché funziona / perché è un errore
[Ragione strutturale]

## Correlati
[Link ad altri file]

## Stato
Provvisorio | Consolidato | Da rivedere

## Ultimo check
Path verificati il YYYY-MM-DD
```

---

## Stato attuale

| Area     | Stato                  | File                                   |
|----------|------------------------|----------------------------------------|
| `ci-cd/` | ✅ Consolidato         | SKILL + workflow + install + branch-protection + applicazione-repo |
| `tdd/`   | ⏳ Scheletro           | Solo SKILL.md (da popolare)            |
| `e2e/`   | ⏳ Scheletro           | Solo SKILL.md (da popolare)            |
