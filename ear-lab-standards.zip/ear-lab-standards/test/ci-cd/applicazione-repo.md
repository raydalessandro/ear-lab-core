# Applicazione ai repo dell'ecosistema

Note specifiche per ciascuno dei 4 repo, basate su com'è oggi il
`package.json`. Il workflow è lo stesso, ma alcuni repo hanno script
mancanti che vale la pena aggiungere prima di abilitare la CI.

## Procedura comune (tutti i repo)

1. Crea la struttura nel repo:
   ```
   .github/
     workflows/
       ci.yml                 ← copia di test/ci-cd/workflow-template.yml
     actions/
       install/
         action.yml           ← copia di test/ci-cd/install-action.yml
   ```

   ⚠️ Nota: il file dentro `actions/install/` deve chiamarsi **`action.yml`**
   (non `install-action.yml`). GitHub cerca quel nome esatto.

2. Apri una PR di test con questa struttura.
3. Verifica che la CI giri verde (con eventuali job opzionali skippati).
4. Mergia, poi applica la branch protection rule (vedi `branch-protection.md`).

## Repo-by-repo

### la-famiglia

**Stato package.json**: ha `lint`, `test`, `test:integration`, `e2e`, `build`.
**Manca**: `typecheck`. Il workflow lo salta automaticamente.

**Aggiunte consigliate al `package.json`** (opzionali ma utili):

```json
"scripts": {
  "typecheck": "tsc --noEmit",
  "test:e2e": "playwright test"
}
```

(Lo script `test:e2e` come alias di `e2e` rende il repo coerente con
Soldi_Lab; il workflow gestisce entrambi i nomi ma uniformare è meglio.)

**Note specifiche**:
- Il job `test:integration` richiede una connessione live a Supabase, quindi
  **non va nella CI standard**. Lascialo come comando manuale.
- Gli E2E Playwright hanno bisogno del server Next.js: verifica che il
  `playwright.config.ts` abbia `webServer` configurato per avviare `npm run dev`
  o `npm run build && npm start` automaticamente.

### Spotimai

**Stato package.json**: ha `test`, `build`. **Manca**: `lint`, `typecheck`,
`test:e2e`. Il workflow li salta automaticamente.

**Aggiunte consigliate**:

```json
"scripts": {
  "lint": "eslint src",
  "typecheck": "tsc --noEmit"
}
```

Per il lint serve anche aggiungere `eslint` e una config minima a
`devDependencies`. Se non hai voglia di farlo subito, il workflow funziona
lo stesso senza.

**Note specifiche**:
- Non ha E2E e probabilmente non ne ha bisogno: è un player privato, la
  superficie di test è piccola.

### Ricette_Lab

**Stato package.json**: ha `lint`, `test`, `build`, `audit`. **Manca**:
`typecheck`, `test:e2e`. **Engines**: `node 22.x`.

**Aggiunte consigliate**:

```json
"scripts": {
  "typecheck": "tsc --noEmit"
}
```

**Note specifiche**:
- Lo script `audit` valida il corpus delle ricette (zero LLM, deterministico).
  È un controllo importantissimo: vale la pena **aggiungerlo al workflow
  come job extra**. Puoi farlo modificando `ci.yml` solo per questo repo,
  oppure (più pulito) chiamandolo dentro `test`:

  ```json
  "test": "node tools/audit.mjs && vitest run"
  ```

- Il `prebuild` lancia già `build-corpus.mjs`, quindi il job `build` della
  CI valida implicitamente che il corpus si compili.

### Soldi_Lab

**Stato package.json**: ha tutto. `lint`, `typecheck`, `test`, `test:e2e`,
`build`. **Package manager**: `pnpm`. Il workflow lo rileva da
`pnpm-lock.yaml`.

**Aggiunte consigliate**: nessuna. È il repo che ha già la disciplina più
matura.

**Note specifiche**:
- Gli E2E sono 10 file Playwright. Se un giorno passano i 5 minuti totali,
  considera di splittare in `test:e2e:smoke` (1-2 file critici) per il push
  e `test:e2e` completo per la PR. Per ora gira tutto.
- Ha già `format:check` con Prettier — puoi aggiungere un job extra al
  workflow di Soldi_Lab se vuoi blocco rigoroso anche sulla formattazione.

## Ordine suggerito di rollout

Non applicare la CI a tutti e 4 contemporaneamente. Procedi in ordine:

1. **Soldi_Lab per primo** — ha tutti gli script, è il caso ideale, verifichi
   che il workflow funziona davvero.
2. **la-famiglia** — è il repo più importante in produzione. Una volta
   verificato su Soldi_Lab, applicalo qui per proteggerlo.
3. **Ricette_Lab** — semplice, statico, basso rischio.
4. **Spotimai** — ultimo perché ha meno script da chiamare e quindi meno
   benefici immediati.

A ogni passaggio, se trovi qualcosa di interessante o un caso che il
workflow non gestisce, **aggiornalo nel template** in `test/ci-cd/` PRIMA
di applicarlo al repo successivo. Questo è il punto della knowledge base:
ogni applicazione la migliora.
