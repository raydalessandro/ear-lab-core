# CI/CD — pattern fisso

> Versione: 2026-05-14
> Status: Consolidato
> Trigger di revisione:
>   - Se la CI totale supera i 10 minuti → rivedere parallelizzazione e selezione test
>   - Se aggiungiamo un repo con stack non-Next.js → rivedere assunzioni sul workflow
>   - Se cambiamo CD da Vercel ad altro → rivedere intera sezione "CD"
>   - Se GitHub Actions cambia API/sintassi → rivedere workflow-template.yml

Decisione chiusa per tutti i repo dell'ecosistema. Non rinegoziare senza
ragione forte e documentata.

## Cosa è e cosa non è

**CI (Continuous Integration)** è il sistema che, a ogni push, esegue
automaticamente una sequenza di controlli sul codice. Nel nostro caso è
**GitHub Actions**.

**CD (Continuous Deployment)** è il sistema che, quando i controlli passano,
deploya automaticamente. Nel nostro caso è **Vercel**, che funziona da solo:
ogni push su `main` → deploy produzione, ogni push su branch → preview deploy.

CI e CD sono **lo scheletro**. I test (unit, integration, e2e), il lint, il
typecheck, il build sono **la carne**: i contenuti che la CI esegue. Sono
due livelli separati. Lo scheletro lo definisci una volta, la carne evolve
con l'esperienza.

## Il pattern

```
1. Apri PR verso main     → CI lancia tutto sul merge ipotetico branch+main
2. Push sul branch        → la PR ri-lancia tutto sul nuovo merge ipotetico
3. Branch protection rule → merge bloccato finché la CI sulla PR è verde
4. Merge su main          → CI su main + Vercel deploya in produzione
```

Quattro punti importanti:

1. **Niente "test diversi" su branch e main.** Stessa identica suite ovunque.
   La complicazione "test pesanti solo su main" la introduci solo quando la
   CI passa i 10 minuti, e oggi non sei lì.
2. **La CI sulla PR testa il merge ipotetico, non il branch.** GitHub Actions
   simula `branch + main` in memoria e gira i test su quello. Questo cattura
   i conflitti d'integrazione che il branch da solo non vedrebbe.
3. **Il feedback sui branch passa dalla PR, non dall'evento `push`.** Il
   workflow ascolta `push` solo su `main`: quando ascoltava anche i branch,
   ogni push su un branch con PR aperta faceva partire due run identiche,
   che non si cancellavano a vicenda perché il concurrency group è diverso.
   Conseguenza da conoscere: **su un branch senza PR aperta la CI non gira.**
   Apri la PR presto, anche in draft, se vuoi il semaforo mentre lavori.
4. **La branch protection rule è non-negoziabile.** Senza quella, la CI è
   solo un semaforo decorativo: vedi rosso, mergi lo stesso. Con la rule
   attiva, il merge è fisicamente bloccato finché non è tutto verde.

## Cosa gira nella CI

Quattro pilastri, sempre:

| Pilastro    | Comando tipico       | Cosa cattura                          |
|-------------|----------------------|---------------------------------------|
| `lint`      | `npm run lint`       | Coerenza stilistica, errori banali    |
| `typecheck` | `npm run typecheck`* | Errori di tipo prima dei test         |
| `build`     | `npm run build`      | Bundle valido, no errori di compile   |
| `test`      | `npm run test`       | Unit + integration                    |
| `e2e`       | `npm run test:e2e`*  | Flussi end-to-end (se applicabili)    |

\* `typecheck` ed `e2e` sono opzionali. Se il `package.json` non li definisce,
il workflow li salta gentilmente senza fallire (vedi `workflow-template.yml`).

**Target di tempo: sotto i 10 minuti totali.** Se ci si avvicina, prima si
parallelizza, poi si seleziona.

## Sequenza operativa (cosa devi fare tu)

1. Copia `ci-cd/workflow-template.yml` in `.github/workflows/ci.yml` del repo.
2. Verifica che il `package.json` esponga gli script che il workflow chiama
   (`lint`, `test`, `build`, idealmente `typecheck` e `test:e2e`).
3. Push del workflow su un branch, apri PR, verifica che la CI parta
   correttamente e tutti i job esistenti diventino verdi.
4. Una volta verde, merge.
5. Vai su GitHub → Settings → Branches → Add branch protection rule per `main`:
   - ✅ Require status checks to pass before merging
   - ✅ Require branches to be up to date before merging
   - ✅ Seleziona tutti i job della CI come "required"
   - ✅ Do not allow bypassing the above settings
6. Da qui in avanti, ogni PR è bloccata al merge finché la CI non passa.

Dettagli step-by-step in `branch-protection.md`.

## Cosa NON mettere nella CI (almeno per ora)

- **Test E2E in produzione**: girano contro `localhost`, non contro Vercel.
- **Performance test**: rumorosi, lenti, flaky. Vivono fuori dalla CI.
- **Deploy step custom**: Vercel fa il deploy da solo, non riproducilo.
- **Notifiche Slack/email**: aggiungono complessità, distraggono. Le aggiungi
  solo quando hai un team.

## Quando si evolve

La CI evolve quando uno di questi tre segnali si manifesta:

1. **La suite supera i 10 minuti.** Inizi a parallelizzare i job (già lo fai
   nel template) o a introdurre selezione per path.
2. **Un bug ricorrente sfugge alla CI.** Aggiungi un nuovo controllo o un
   nuovo test che lo avrebbe catturato. *Aggiorna anche il pattern* in
   `tdd/anti-patterns/` o `e2e/anti-patterns/`.
3. **Un controllo dà falsi positivi ricorrenti.** Lo togli o lo rivedi. Una
   CI rumorosa è peggio di una CI assente: la ignori, e quando un vero
   problema arriva non te ne accorgi.

## Decisione chiusa

- ✅ GitHub Actions, non altri sistemi (CircleCI, Travis, GitLab).
- ✅ Vercel per il CD, non deploy custom.
- ✅ Workflow unico per repo, in `.github/workflows/ci.yml`.
- ✅ Branch protection abilitata su `main`, sempre.
- ✅ Stessi job ovunque la CI giri: nessuna suite ridotta.
- ✅ Un solo evento per contesto: `pull_request` sui branch, `push` su main.
- ❌ No deploy manuali.
- ❌ No merge senza CI verde.
- ❌ No skip dei test "tanto è una piccola modifica".

## Changelog
- 2026-05-14: prima versione consolidata. Pattern fisso definito, workflow universale per i 4 repo dell'ecosistema, branch protection rule documentata.
- 2026-08-13: il sentinel `CI Success` non può più diventare verde a vuoto quando `setup` fallisce; corretta la detection di `has-e2e`; `push` limitato a `main` per eliminare la doppia run sui branch con PR aperta.
