# Branch Protection — setup operativo

Senza branch protection la CI è un semaforo decorativo. Con la rule
attiva, GitHub blocca il merge finché la CI non è verde. È il passo che
trasforma il pattern da "auspicio" a "vincolo strutturale".

## Setup step-by-step

Da fare **una volta per repo**, dopo aver pushato `.github/workflows/ci.yml`
su main e verificato che la CI giri.

1. Apri il repo su GitHub → **Settings** → **Branches**.
2. Sotto "Branch protection rules" → **Add branch ruleset** (o "Add rule",
   l'UI cambia ogni tanto).
3. **Branch name pattern**: `main`
4. Attiva le seguenti opzioni:

### Le opzioni che vuoi attive

| Opzione | Valore |
|---------|--------|
| ✅ Require a pull request before merging | ON |
| └─ Require approvals | 0 (sei solo, ma quando avrai un collaboratore metti 1) |
| └─ Dismiss stale pull request approvals when new commits are pushed | ON |
| ✅ Require status checks to pass before merging | ON |
| └─ Require branches to be up to date before merging | ON |
| └─ Status checks that are required: | `CI Success` |
| ✅ Require conversation resolution before merging | ON |
| ✅ Do not allow bypassing the above settings | ON |
| ❌ Allow force pushes | OFF |
| ❌ Allow deletions | OFF |

### Perché "CI Success" e non i singoli job

Il workflow definisce un job finale chiamato `ci-success` che si chiude in
verde solo se tutti gli altri sono verdi (o skippati gentilmente). Mettendo
solo questo come "required status check" eviti di dover aggiornare la
branch protection ogni volta che aggiungi un job nuovo al workflow.

### Per trovare lo status check nella lista

Il dropdown "Status checks that are required" mostra solo i job che hanno
girato **almeno una volta**. Quindi la sequenza è:

1. Aggiungi `.github/workflows/ci.yml` su un branch.
2. Apri una PR finta verso main per far girare la CI.
3. Una volta che la CI ha girato, vai nella branch protection rule.
4. Cerca `CI Success` nel dropdown — ora c'è.
5. Aggiungilo come required.
6. Salva la rule.
7. Mergi la PR.

## Verifica che funzioni

Crea un branch, fai un commit con un errore *intenzionale* (es. un typo
TS che fa fallire `typecheck` o `build`), apri PR.

Devi vedere:
- ❌ CI rossa sulla PR
- 🚫 Bottone "Merge pull request" disabilitato con messaggio "Required
  status check 'CI Success' is expected"

Se vedi questo, la rule è attiva e funziona. Cancella il branch e procedi
sereno.

## Cosa fare se ti blocchi (emergency override)

Mai. Davvero, mai. La tentazione di "disattivo la rule per cinque minuti
per mergiare questo fix urgente" è il primo passo verso una codebase dove
la rule non è più rispettata da nessuno. Se la CI è rotta:

1. **Se è rotta la CI stessa** (es. GitHub Actions down): aspetta. Sono
   sempre crash brevi.
2. **Se è rotto un test flaky**: aggiusta il test, non disattivare la rule.
   Anti-pattern, vedi `e2e/anti-patterns/01-flaky-timing.md`.
3. **Se è rotto un test perché la modifica è giusta e il test è obsoleto**:
   aggiorna il test nella stessa PR. È il caso più comune e legittimo.

Se davvero servisse un bypass d'emergenza, la rule lo permette solo
disattivandola, ed è loggato. Meglio non normalizzare quel pattern.
