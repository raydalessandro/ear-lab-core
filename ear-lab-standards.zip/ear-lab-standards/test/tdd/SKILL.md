# TDD — pattern di test unit e integration

> Versione: 2026-05-14
> Status: Provvisorio (scheletro, da popolare con i primi pattern)
> Trigger di revisione:
>   - Quando aggiungiamo il primo pattern reale → rivedere assunzioni
>   - Quando un anti-pattern si manifesta 3 volte → promuoverlo da casi
>     specifici a regola generale qui

---

## Decisioni chiuse (per ora)

Queste sono le scelte già consolidate sull'ecosistema, derivate
dall'analisi delle codebase esistenti (Soldi_Lab in primis).

### Stack

- **Test runner**: Vitest. Non Jest, non Mocha.
- **Linguaggio**: TypeScript, sempre. Niente file `.test.js`.
- **Naming**: `nome-modulo.test.ts`, accanto al file testato, **non** in
  cartelle separate `__tests__/`. Co-locazione: il test sta col codice.
- **Eseguibili da CI senza setup speciali**: niente DB esterni, niente
  network, niente file system al di fuori di tmpfs.

### Pattern fondamentale: dependency injection sui boundary

Funzioni che parlano con il DB, con il filesystem, o con servizi esterni
**devono** accettare la dipendenza come ultimo parametro opzionale,
con un default che usa la dipendenza reale.

Esempio canonico (da Soldi_Lab):

```ts
export async function createFloorItem(
  input: CreateFloorItemInput,
  db: SoldiLabDB = getDB(),   // ← default reale, override testabile
): Promise<FloorItem> { /* ... */ }
```

Nei test:

```ts
const db = makeTestDB();   // istanza isolata
await createFloorItem({ ... }, db);
```

**Perché**: rende le funzioni testabili senza mocking library, senza monkey
patching, senza setup globali. Il test è leggibile come un programma.

### Funzioni pure dove possibile

Calcoli, trasformazioni, aggregazioni: nessun side effect. Input → output
deterministico. Si testano con `expect(fn(input)).toEqual(output)`, fine.

Antitesi: funzioni che chiamano `new Date()`, `Math.random()`, o leggono
`process.env` direttamente. Tutte queste dipendenze vanno iniettate come
parametri (`today: ISODate`, `randomSeed: number`, `config: Config`).

### Cosa va testato

- **Funzioni pure**: sempre, e in profondità. Casi tipici + edge case +
  errori.
- **Repository (CRUD)**: sempre, con DB isolato per test (vedi
  `makeTestDB` di Soldi_Lab come riferimento).
- **Validatori Zod**: sempre, con casi validi + casi invalidi noti.
- **Logica di business critica** (auth, calcoli finanziari, normalizzazioni
  di unità): sempre, con copertura difensiva.

### Cosa NON va testato

- **Componenti React puramente visuali**: né con snapshot test (rumorosi)
  né con react-testing-library (poco valore). Se un componente ha logica,
  estrai la logica in funzione pura e testa quella.
- **Wrapper triviali**: una funzione che chiama una libreria e non fa
  altro non merita un test.
- **Tipi TypeScript**: il compilatore è il loro test. Non scrivere test
  che verificano "che il tipo X esiste".

---

## Pattern (da popolare)

`patterns/` raccoglierà:
- `01-dependency-injection-su-boundary.md`
- `02-funzioni-pure-deterministi che.md`
- `03-test-isolation-via-db-istanze.md`
- `04-snapshot-testing-su-output-stabili.md` (es. export AI di Soldi_Lab)
- ...

## Anti-pattern (da popolare)

`anti-patterns/` raccoglierà:
- `01-mock-eccessivi.md` — più di 3 mock = funzione mal disegnata
- `02-test-accoppiati-a-implementazione.md`
- `03-test-flaky-per-tempo.md` — `new Date()` non iniettato
- `04-test-che-passano-su-scenario-sbagliato.md` — la firma AI
- ...

---

## Changelog

- 2026-05-14: scheletro iniziale con decisioni chiuse derivate dall'analisi
  di Soldi_Lab e la-famiglia. Pattern concreti da popolare nelle prossime
  revisioni.
